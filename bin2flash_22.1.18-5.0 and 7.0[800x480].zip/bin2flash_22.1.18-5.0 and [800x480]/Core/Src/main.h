#include "stm32g0xx_hal.h"
#include "stm32g0xx_ll_dma.h"
#include "stm32g0xx_ll_rcc.h"
#include "stm32g0xx_ll_bus.h"
#include "stm32g0xx_ll_system.h"
#include "stm32g0xx_ll_exti.h"
#include "stm32g0xx_ll_cortex.h"
#include "stm32g0xx_ll_utils.h"
#include "stm32g0xx_ll_pwr.h"
#include "stm32g0xx_ll_usart.h"
#include "stm32g0xx_ll_gpio.h"
#include "core_cm0plus.h"
#include "system_stm32g0xx.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"

#define  ASCII8x16_SIZE       1520
#define  ASCII16x24_SIZE      4560
#define  ASCII16x32_SIZE      6080
#define  TEXT16x16_SIZE       766080
#define  TEXT24x24_SIZE       1723680
#define  TEXT32x32_SIZE       3064320

#define  ASCII8x16_ADDR       0
#define  ASCII16x24_ADDR      ASCII8x16_SIZE
#define  ASCII16x32_ADDR      ASCII16x24_ADDR+ASCII16x24_SIZE
#define  TEXT16x16_ADDR       ASCII16x32_ADDR+ASCII16x32_SIZE
#define  TEXT24x24_ADDR       TEXT16x16_ADDR +TEXT16x16_SIZE
#define  TEXT32x32_ADDR       TEXT24x24_ADDR +TEXT24x24_SIZE
#define  PIC_ADDR             TEXT32x32_ADDR +TEXT32x32_SIZE

#define red 0xf800
#define green 0x07e0
#define blue 0x001f
#define white 0xffff
#define yellow 0xffe0

const uint32_t BINARY_INFO[][5]=
{
  /*  No. , Width , Height , Size , Start Address  */ 
  {1,800,480,768000,0},          /*     0 , element 0     */
  {2,800,480,768000,768000},          /*     1 , element 1     */
  {3,800,480,768000,1536000},          /*     2 , element 2     */
  {4,800,480,768000,2304000},          /*     3 , element 3     */
  {5,800,480,768000,3072000},          /*     4 , element 4     */
  {6,800,480,768000,3840000},          /*     5 , element 5     */
  {7,240,140,67200,4608000},          /*     10 , element 6     */
  {8,240,140,67200,4675200},          /*     12 , element 7     */
  {9,320,240,153600,4742400},          /*     container_poweron1_0 , element 8     */
  {10,320,240,153600,4896000},          /*     container_poweron2_0 , element 9     */
  {11,320,240,153600,5049600},          /*     container_poweron3_0 , element 10     */
  {12,320,240,153600,5203200},          /*     container_poweron4_0 , element 11     */
  {13,320,240,153600,5356800},          /*     container_poweron5_0 , element 12     */
  {14,320,240,153600,5510400},          /*     container_poweron6_0 , element 13     */
  {15,320,240,153600,5664000},          /*     container_poweron7_0 , element 14     */
  {16,320,240,153600,5817600},          /*     container_poweron8_0 , element 15     */
  {17,320,240,153600,5971200},          /*     container_poweron9_0 , element 16     */
  {18,32,50,3200,6124800},          /*     D0 , element 17     */
  {19,32,50,3200,6128000},          /*     D1 , element 18     */
  {20,32,50,3200,6131200},          /*     D2 , element 19     */
  {21,32,50,3200,6134400},          /*     D3 , element 20     */
  {22,32,50,3200,6137600},          /*     D4 , element 21     */
  {23,32,50,3200,6140800},          /*     D5 , element 22     */
  {24,32,50,3200,6144000},          /*     D6 , element 23     */
  {25,32,50,3200,6147200},          /*     D7 , element 24     */
  {26,32,50,3200,6150400},          /*     D8 , element 25     */
  {27,32,50,3200,6153600},          /*     D9 , element 26     */
  {28,10,50,1000,6156800},          /*     D10 , element 27     */
  {29,16,24,768,6157800},          /*     DDD0 , element 28     */
  {30,16,24,768,6158568},          /*     DDD1 , element 29     */
  {31,16,24,768,6159336},          /*     DDD2 , element 30     */
  {32,16,24,768,6160104},          /*     DDD3 , element 31     */
  {33,16,24,768,6160872},          /*     DDD4 , element 32     */
  {34,16,24,768,6161640},          /*     DDD5 , element 33     */
  {35,16,24,768,6162408},          /*     DDD6 , element 34     */
  {36,16,24,768,6163176},          /*     DDD7 , element 35     */
  {37,16,24,768,6163944},          /*     DDD8 , element 36     */
  {38,16,24,768,6164712},          /*     DDD9 , element 37     */
  {39,5,24,240,6165480},          /*     DDD10 , element 38     */
};

// ====================================
//-----usart.c---------------
extern void USART1_Init(uint32_t baud);
extern void UART1_Send_NBytes(uint8_t *Data, uint16_t Len);
extern void UART1_Send_NChars(char * dat);
extern uint8_t  USART_RX_BUFF[]; //SIZE = 520
extern uint16_t USART1_RX_STA;   //接收状态标记	bit15:一帧数据完成   bit14-0:一帧数据长度
//-----sysclk.c---------------
extern void SystemClock_Config(void);
//-----fat.c---------------
extern uint8_t UART2FLASH_Binfile(uint8_t DelayNms);//从TF卡中读BIN文件并通过串口发送给UART LCM，延时设置为0ms(读TF卡时本身有延时1ms，只有在低波特率时才用)
extern uint8_t SPI2FLASH_Binfile(uint8_t FormatAllChipYesNo,uint32_t WriteAddr);
//-----spi.c---------------
extern void FLASH_SW_L(void);
extern void FLASH_SW_H(void);
extern void FLASH_CS_L(void);
extern void FLASH_CS_H(void);
extern void TF_CS_L(void);
extern void TF_CS_H(void);
extern void FLASH_SPIGPIO_Init_16M(void);
extern void FLASH_SPIGPIO_Init_8M(void);
extern void FLASH_SPIGPIO_Init_4M(void);
extern void FLASH_SPIGPIO_Init_2M(void);
extern void TF_SPIGPIO_Init(void);
extern uint8_t FLASH_ReadWriteByte(uint8_t byte);
extern uint8_t TF_ReadWriteByte(uint8_t byte);
//-----spitft.c---------------
extern uint16_t Hsize;
extern uint16_t Vsize;
extern uint8_t  BL_PWM;

extern uint32_t Get_XY2DramAddr(uint16_t X,uint16_t Y);
extern uint8_t SPI_Check_Busy(void);
extern void Set_NP4185_Comd(uint8_t COMD,uint32_t Dram_addr,uint32_t Flash_addr,uint16_t H_size,uint16_t V_size,uint8_t BL_PWM);
extern void Set_NP4185_DotComd(uint16_t X,uint16_t Y,uint16_t color);
extern void LCD_DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
extern void LCD_DrawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
extern void LCD_DrawRectangleFill(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint16_t color);
extern void draw_circle_8( uint16_t xc, uint16_t yc, uint16_t x, uint16_t y, uint16_t c);
extern void LCD_DrawCircleFill( uint16_t xc, uint16_t yc, uint16_t r, uint8_t fill, uint16_t color);
extern void LCD_Draw1Char(uint16_t x,uint16_t y,uint16_t CharBytes,uint8_t cwidth,uint8_t cheight,uint8_t *p,uint16_t font_color,uint16_t back_color);
extern void LCD_ShowStringCharMode(uint32_t caddr,uint32_t taddr,uint16_t x,uint16_t y,uint8_t width,uint8_t height,uint8_t *p,uint8_t cbyte,uint16_t font_color,uint16_t back_color,uint8_t mode);
extern void LCD_ShowStringBlockMode(uint32_t caddr,uint32_t taddr,uint16_t x,uint16_t y,uint8_t width,uint8_t height,uint8_t *p,uint8_t cbyte,uint16_t font_color,uint16_t back_color);
extern void LCD_ShowPic4Flash(uint16_t x,uint16_t y,uint32_t FlashAdrr,uint16_t PicWidth,uint16_t Picheight);
extern void LCD_ShowPic4SPI(uint16_t x,uint16_t y,const uint8_t *PIC,uint16_t PicWidth,uint16_t Picheight);
//-----W25QXX.c---------------
extern uint16_t W25QXX_Init(void);
extern uint16_t W25QXX_ReadID(void);  	    		//读取FLASH ID
extern uint8_t	 W25QXX_ReadSR(void);        		//读取状态寄存器 
extern void W25QXX_Write_SR(uint8_t sr);  			//写状态寄存器
extern void W25QXX_Write_Enable(void);  		//写使能 
extern void W25QXX_Write_Disable(void);		//写保护
extern void W25QXX_Write_NoCheck(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite);
extern void W25QXX_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint16_t NumByteToRead);   //读取flash
extern void W25QXX_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite);//写入flash
extern void W25QXX_Erase_Chip(void);    	  	//整片擦除
extern void W25QXX_Erase_Sector(uint32_t Dst_Addr);	//扇区擦除
extern void W25QXX_Wait_Busy(void);           	//等待空闲
extern void W25QXX_PowerDown(void);        	//进入掉电模式
extern void W25QXX_WAKEUP(void);				//唤醒
