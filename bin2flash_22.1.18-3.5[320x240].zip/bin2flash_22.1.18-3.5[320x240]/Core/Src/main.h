#include "stm32g0xx_hal.h"
#include "stm32g0xx_ll_dma.h"
#include "stm32g0xx_ll_rcc.h"
#include "stm32g0xx_ll_bus.h"
#include "stm32g0xx_ll_system.h"
#include "stm32g0xx_ll_exti.h"
#include "stm32g0xx_ll_cortex.h"
#include "stm32g0xx_ll_utils.h"
#include "stm32g0xx_ll_pwr.h"
#include "stm32g0xx_ll_usart.h"
#include "stm32g0xx_ll_gpio.h"
#include "core_cm0plus.h"
#include "system_stm32g0xx.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"

#define  ASCII16x24_SIZE      4560
#define  TEXT24x24_SIZE       1723680
#define  ASCII16x24_ADDR      0
#define  TEXT24x24_ADDR       ASCII16x24_ADDR+ASCII16x24_SIZE
#define  PIC_ADDR       			TEXT24x24_ADDR+TEXT24x24_SIZE

#define red 0xf800
#define green 0x07e0
#define blue 0x001f
#define white 0xffff
#define yellow 0xffe0

const uint32_t BINARY_INFO[][5]=
{
  /*  No. , Width , Height , Size , Start Address  */ 
  {1,320,240,153600,0},          /*     1 , element 0     */
  {2,320,240,153600,153600},          /*     2 , element 1     */
  {3,320,240,153600,307200},          /*     3 , element 2     */
  {4,320,240,153600,460800},          /*     4 , element 3     */
  {5,320,240,153600,614400},          /*     5 , element 4     */
  {6,320,240,153600,768000},          /*     6 , element 5     */
  {7,320,240,153600,921600},          /*     7 , element 6     */
  {8,320,240,153600,1075200},          /*     container_poweron1_0 , element 7     */
  {9,320,240,153600,1228800},          /*     container_poweron2_0 , element 8     */
  {10,320,240,153600,1382400},          /*     container_poweron3_0 , element 9     */
  {11,320,240,153600,1536000},          /*     container_poweron4_0 , element 10     */
  {12,320,240,153600,1689600},          /*     container_poweron5_0 , element 11     */
  {13,320,240,153600,1843200},          /*     container_poweron6_0 , element 12     */
  {14,320,240,153600,1996800},          /*     container_poweron7_0 , element 13     */
  {15,320,240,153600,2150400},          /*     container_poweron8_0 , element 14     */
  {16,320,240,153600,2304000},          /*     container_poweron9_0 , element 15     */
  {17,14,19,532,2457600},          /*     static_containerhz_r0_0 , element 16     */
  {18,14,19,532,2458132},          /*     static_containerhz_r1_0 , element 17     */
  {19,14,19,532,2458664},          /*     static_containerhz_r2_0 , element 18     */
  {20,14,19,532,2459196},          /*     static_containerhz_r3_0 , element 19     */
  {21,14,19,532,2459728},          /*     static_containerhz_r4_0 , element 20     */
  {22,14,19,532,2460260},          /*     static_containerhz_r5_0 , element 21     */
  {23,14,19,532,2460792},          /*     static_containerhz_r6_0 , element 22     */
  {24,14,19,532,2461324},          /*     static_containerhz_r7_0 , element 23     */
  {25,14,19,532,2461856},          /*     static_containerhz_r8_0 , element 24     */
  {26,14,19,532,2462388},          /*     static_containerhz_r9_0 , element 25     */
  {27,14,19,532,2462920},          /*     static_containerhz0_0 , element 26     */
};
// ====================================
//-----usart.c---------------
extern void USART1_Init(uint32_t baud);
extern void UART1_Send_NBytes(uint8_t *Data, uint16_t Len);
extern void UART1_Send_NChars(char * dat);
extern uint8_t  USART_RX_BUFF[]; //SIZE = 520
extern uint16_t USART1_RX_STA;   //接收状态标记	bit15:一帧数据完成   bit14-0:一帧数据长度
//-----sysclk.c---------------
extern void SystemClock_Config(void);
//-----fat.c---------------
extern uint8_t UART2FLASH_Binfile(uint8_t DelayNms);//从TF卡中读BIN文件并通过串口发送给UART LCM，延时设置为0ms(读TF卡时本身有延时1ms，只有在低波特率时才用)
extern uint8_t SPI2FLASH_Binfile(uint8_t FormatAllChipYesNo,uint32_t WriteAddr);
//-----spi.c---------------
extern void FLASH_SW_L(void);
extern void FLASH_SW_H(void);
extern void FLASH_CS_L(void);
extern void FLASH_CS_H(void);
extern void TF_CS_L(void);
extern void TF_CS_H(void);
extern void FLASH_SPIGPIO_Init_16M(void);
extern void FLASH_SPIGPIO_Init_8M(void);
extern void FLASH_SPIGPIO_Init_4M(void);
extern void TF_SPIGPIO_Init(void);
extern uint8_t FLASH_ReadWriteByte(uint8_t byte);
extern uint8_t TF_ReadWriteByte(uint8_t byte);
//-----spitft.c---------------
extern uint16_t Hsize;
extern uint16_t Vsize;
extern uint8_t  BL_PWM;

extern uint32_t Get_XY2DramAddr(uint16_t X,uint16_t Y);
extern uint8_t SPI_Check_Busy(void);
extern void Set_NP4185_Comd(uint8_t COMD,uint32_t Dram_addr,uint32_t Flash_addr,uint16_t H_size,uint16_t V_size,uint8_t BL_PWM);
extern void Set_NP4185_DotComd(uint16_t X,uint16_t Y,uint16_t color);
extern void LCD_DrawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
extern void LCD_DrawRectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
extern void LCD_DrawRectangleFill(uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint16_t color);
extern void draw_circle_8( uint16_t xc, uint16_t yc, uint16_t x, uint16_t y, uint16_t c);
extern void LCD_DrawCircleFill( uint16_t xc, uint16_t yc, uint16_t r, uint8_t fill, uint16_t color);
extern void LCD_Draw1Char(uint16_t x,uint16_t y,uint16_t CharBytes,uint8_t cwidth,uint8_t cheight,uint8_t *p,uint16_t font_color,uint16_t back_color);
extern void LCD_ShowStringCharMode(uint32_t caddr,uint32_t taddr,uint16_t x,uint16_t y,uint8_t width,uint8_t height,uint8_t *p,uint8_t cbyte,uint16_t font_color,uint16_t back_color,uint8_t mode);
extern void LCD_ShowStringBlockMode(uint32_t caddr,uint32_t taddr,uint16_t x,uint16_t y,uint8_t width,uint8_t height,uint8_t *p,uint8_t cbyte,uint16_t font_color,uint16_t back_color);
extern void LCD_ShowPic4Flash(uint16_t x,uint16_t y,uint32_t FlashAdrr,uint16_t PicWidth,uint16_t Picheight);
extern void LCD_ShowPic4SPI(uint16_t x,uint16_t y,const uint8_t *PIC,uint16_t PicWidth,uint16_t Picheight);
//-----W25QXX.c---------------
extern uint16_t W25QXX_Init(void);
extern uint16_t W25QXX_ReadID(void);  	    		//读取FLASH ID
extern uint8_t	 W25QXX_ReadSR(void);        		//读取状态寄存器 
extern void W25QXX_Write_SR(uint8_t sr);  			//写状态寄存器
extern void W25QXX_Write_Enable(void);  		//写使能 
extern void W25QXX_Write_Disable(void);		//写保护
extern void W25QXX_Write_NoCheck(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite);
extern void W25QXX_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint16_t NumByteToRead);   //读取flash
extern void W25QXX_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite);//写入flash
extern void W25QXX_Erase_Chip(void);    	  	//整片擦除
extern void W25QXX_Erase_Sector(uint32_t Dst_Addr);	//扇区擦除
extern void W25QXX_Wait_Busy(void);           	//等待空闲
extern void W25QXX_PowerDown(void);        	//进入掉电模式
extern void W25QXX_WAKEUP(void);				//唤醒
